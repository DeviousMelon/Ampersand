import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Random;

// The main class that extends JPanel and implements ActionListener to handle game events
public class SnakeGame extends JPanel implements ActionListener {

    // Constants for game size, dot (snake part) size, and border size
    private final int WIDTH = 500;
    private final int HEIGHT = 500;
    private final int DOT_SIZE = 10;
    private final int BORDER_SIZE = 40;

    // Declare the Snake object, apple (food) position, game timer, score, and game states
    private Snake snake;
    private Point apple;
    private Timer timer;
    private int score = 0;
    private boolean inGame = true; // Indicates whether the game is active

    // Label to display the current score
    private final JLabel scoreLabel;

    // Random object for generating random apple positions
    private final Random random = new Random();

    // Constructor initializes the game panel
    public SnakeGame() {
        setBackground(Color.black); // Set background color to black
        setPreferredSize(new Dimension(WIDTH, HEIGHT)); // Set the size of the game window
        setFocusable(true); // Enable focus for keyboard input

        // Initialize the score label and set its appearance
        scoreLabel = new JLabel("Score: 0");
        scoreLabel.setForeground(Color.white);
        add(scoreLabel); // Add score label to the panel

        // Add a restart button and define its action to reset the game
        JButton restartButton = new JButton("Restart");
        restartButton.addActionListener(e -> resetGame());
        add(restartButton); // Add the restart button to the panel

        // Add a key listener to capture key presses for controlling the snake
        addKeyListener(new TAdapter());

        // Initialize the game
        initGame();
    }

    // Method to initialize the game (snake, apple, score, etc.)
    private void initGame() {
        snake = new Snake(); // Create a new Snake object
        apple = generateApple(); // Generate the first apple (food) at a random position
        score = 0; // Reset the score
        updateScoreLabel(); // Update the score label display

        // Stop the previous timer if it exists
        if (timer != null) {
            timer.stop();
        }

        // Set the game speed and start the timer to drive game updates
        int GAME_SPEED = 0;
        timer = new Timer(GAME_SPEED, this);
        timer.start();

        inGame = true; // Mark the game as active
    }

    // Reset the game to its initial state
    private void resetGame() {
        timer.stop(); // Stop the game timer
        initGame(); // Re-initialize the game
        requestFocusInWindow(); // Request focus to capture key presses again
    }

    // Generate a random position for the apple within the game borders
    private Point generateApple() {
        int x = BORDER_SIZE + random.nextInt((WIDTH - 2 * BORDER_SIZE) / DOT_SIZE) * DOT_SIZE;
        int y = BORDER_SIZE + random.nextInt((HEIGHT - 2 * BORDER_SIZE) / DOT_SIZE) * DOT_SIZE;
        return new Point(x, y);
    }

    // Update the score label with the current score
    private void updateScoreLabel() {
        scoreLabel.setText("Score: " + score);
    }

    // Paint the game components (snake, apple, etc.)
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g); // Call parent method for background rendering
        if (inGame) {
            drawGame(g); // Draw the game components when inGame is true
        } else {
            drawGameOver(g); // Draw the game over screen when the game ends
        }
    }

    // Draw the snake, apple, and game borders during gameplay
    private void drawGame(Graphics g) {
        // Draw Apple (food) as a red oval
        g.setColor(Color.RED);
        g.fillOval(apple.x, apple.y, DOT_SIZE, DOT_SIZE);

        // Draw Snake
        snake.draw(g);

        // Draw game borders
        g.setColor(Color.WHITE);
        g.drawRect(BORDER_SIZE, BORDER_SIZE, WIDTH - 2 * BORDER_SIZE, HEIGHT - 2 * BORDER_SIZE);

        // Sync graphics to improve rendering smoothness
        Toolkit.getDefaultToolkit().sync();
    }

    // Display the "Game Over" message when the game ends
    private void drawGameOver(Graphics g) {
        String message = "Game Over"; // Game over message
        Font font = new Font("Helvetica", Font.BOLD, 20); // Set the font for the message
        FontMetrics metrics = getFontMetrics(font); // Calculate the width of the text for centering
        g.setColor(Color.white); // Set text color to white
        g.setFont(font); // Apply the font
        g.drawString(message, (WIDTH - metrics.stringWidth(message)) / 2, HEIGHT / 2); // Draw the message centered
    }

    // This method is called by the timer every frame to update the game
    @Override
    public void actionPerformed(ActionEvent e) {
        if (inGame) { // Update only if the game is active
            snake.move(); // Move the snake
            checkApple(); // Check if the snake has eaten the apple
            checkCollisions(); // Check for collisions (with itself or the borders)
        }
        repaint(); // Repaint the screen after each update
    }

    // Check if the snake's head is on the apple
    private void checkApple() {
        if (snake.getHead().equals(apple)) { // If snake eats the apple
            snake.grow(); // Grow the snake
            score++; // Increase the score
            updateScoreLabel(); // Update the score label
            apple = generateApple(); // Generate a new apple
        }
    }

    // Check if the snake collides with itself or the game borders
    private void checkCollisions() {
        if (snake.collidesWithItself() || snake.collidesWithBorder(WIDTH, HEIGHT, BORDER_SIZE)) {
            inGame = false; // End the game
            timer.stop(); // Stop the game timer
        }
    }

    // KeyAdapter to handle arrow key presses for snake control
    private class TAdapter extends KeyAdapter {
        @Override
        public void keyPressed(KeyEvent e) {
            int key = e.getKeyCode(); // Get the pressed key code
            snake.setDirection(key); // Set snake direction based on the pressed key
        }
    }
}

// Snake class encapsulates snake-specific logic and behavior
class Snake {
    private final int DOT_SIZE = 10; // Size of each segment of the snake
    private final ArrayList<Point> body; // Snake's body segments as a list of points
    private int directionX = 1; // Direction of movement along the X-axis (1 for right, -1 for left)
    private int directionY = 0; // Direction of movement along the Y-axis (1 for down, -1 for up)

    // Constructor initializes the snake with a starting length of 3 segments
    public Snake() {
        body = new ArrayList<>();
        body.add(new Point(100, 100)); // Head of the snake
        body.add(new Point(90, 100));  // Second segment
        body.add(new Point(80, 100));  // Third segment
    }

    // Get the head of the snake (first segment)
    public Point getHead() {
        return body.getFirst();
    }

    // Move the snake by shifting the positions of each body segment
    public void move() {
        for (int i = body.size() - 1; i > 0; i--) {
            body.set(i, new Point(body.get(i - 1)));
        }
        body.set(0, new Point(body.getFirst().x + directionX * DOT_SIZE, body.getFirst().y + directionY * DOT_SIZE));
    }

    // Set the snake's direction based on arrow key input
    public void setDirection(int keyCode) {
        switch (keyCode) {
            case KeyEvent.VK_LEFT:
                if (directionX != 1) { directionX = -1; directionY = 0; }
                break;
            case KeyEvent.VK_RIGHT:
                if (directionX != -1) { directionX = 1; directionY = 0; }
                break;
            case KeyEvent.VK_UP:
                if (directionY != 1) { directionX = 0; directionY = -1; }
                break;
            case KeyEvent.VK_DOWN:
                if (directionY != -1) { directionX = 0; directionY = 1; }
                break;
        }
    }

    // Grow the snake by adding a new segment at the tail
    public void grow() {
        body.add(new Point(body.getLast()));
    }

    // Check if the snake collides with itself
    public boolean collidesWithItself() {
        Point head = getHead();
        for (int i = 1; i < body.size(); i++) {
            if (head.equals(body.get(i))) {
                return true;
            }
        }
        return false;
    }

    // Check if the snake's head collides with the game borders
    public boolean collidesWithBorder(int width, int height, int borderSize) {
        Point head = getHead();
        return head.x < borderSize || head.x >= width - borderSize || head.y < borderSize || head.y >= height - borderSize;
    }

    // Draw the snake on the game screen
    public void draw(Graphics g) {
        g.setColor(Color.ORANGE); // Set snake color to orange
        for (Point point : body) {
            g.fillRect(point.x, point.y, DOT_SIZE, DOT_SIZE); // Draw each snake segment as a rectangle
        }
    }

    // Main method to create and display the game window
    public static void main(String[] args) {
        JFrame frame = new JFrame("Snake"); // Create a new game window
        SnakeGame game = new SnakeGame(); // Create a new game panel
        frame.add(game); // Add the game panel to the window
        frame.pack(); // Adjust the window size to fit the game panel
        frame.setLocationRelativeTo(null); // Center the window on the screen
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Ensure the game closes when the window is closed
        frame.setVisible(true); // Make the window visible
    }
}