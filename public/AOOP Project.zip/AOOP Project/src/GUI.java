import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class GUI {
    private JPanel rootPanel;
    private JPanel menuPanel;
    private JButton atmButton;
    private JButton officerButton;
    private JPanel atmPanel;
    private JTextField accountIDtext;
    private JButton depositButton;
    private JButton withdrawButton;
    private JButton checkBalanceButton;
    private JButton logoutButton;
    private JRadioButton depositAccountRadioButton;
    private JRadioButton currentAccountRadioButton;
    private JPanel officerPanel;
    private JButton createNewAccountButton;
    private JButton changeAIRButton;
    private JButton changeOverdraftLimitButton;

    private ButtonGroup accountTypeGroup;

    public static ArrayList<Account> thomondAccounts = new ArrayList<>();

    public GUI() {
        setupButtonGroup();
        setupListeners();
        testAccounts();
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                accountIDtext.setText("");
            }
        });
    }

    private void setupButtonGroup() {
        accountTypeGroup = new ButtonGroup();
        accountTypeGroup.add(depositAccountRadioButton);
        accountTypeGroup.add(currentAccountRadioButton);
    }

    private void setupListeners() {
        //atmButton.addActionListener(e -> switchPanel(atmPanel));
        //officerButton.addActionListener(e -> switchPanel(officerPanel));
        //logoutButton.addActionListener(e -> switchPanel(menuPanel));

        depositButton.addActionListener(e -> {
            try {
                int id = Integer.parseInt(accountIDtext.getText());
                Account acc = findAccount(id);
                if (acc != null) {
                    double amount = Double.parseDouble(JOptionPane.showInputDialog("Enter amount to deposit:"));
                    acc.deposit(amount);
                    JOptionPane.showMessageDialog(null, "Deposited: €" + amount);
                } else {
                    showMessage("Account not found.");
                }
            } catch (Exception ex) {
                showMessage("Invalid input.");
            }
        });

        withdrawButton.addActionListener(e -> {
            try {
                int id = Integer.parseInt(accountIDtext.getText());
                Account acc = findAccount(id);
                if (acc != null) {
                    double amount = Double.parseDouble(JOptionPane.showInputDialog("Enter amount to withdraw:"));
                    boolean result = acc.withdraw(amount);
                    if (result) {
                        showMessage("Withdrawn: €" + amount);
                    } else {
                        showMessage("Insufficient funds or overdraft limit exceeded.");
                    }
                } else {
                    showMessage("Account not found.");
                }
            } catch (Exception ex) {
                showMessage("Invalid input.");
            }
        });

        checkBalanceButton.addActionListener(e -> {
            try {
                int id = Integer.parseInt(accountIDtext.getText());
                Account acc = findAccount(id);
                if (acc != null) {
                    showMessage("Current Balance: €" + acc.getBalance());
                } else {
                    showMessage("Account not found.");
                }
            } catch (Exception ex) {
                showMessage("Invalid input.");
            }
        });

        createNewAccountButton.addActionListener(e -> {
            try {
                int id = Integer.parseInt(JOptionPane.showInputDialog("Enter Account ID:"));
                int custNo = Integer.parseInt(JOptionPane.showInputDialog("Enter Customer No:"));

                if (depositAccountRadioButton.isSelected()) {
                    thomondAccounts.add(new DepositAccount(id, custNo));
                    showMessage("Deposit Account created.");
                } else if (currentAccountRadioButton.isSelected()) {
                    double overdraft = Double.parseDouble(JOptionPane.showInputDialog("Enter Overdraft Limit:"));
                    thomondAccounts.add(new CurrentAccount(id, custNo, overdraft));
                    showMessage("Current Account created.");
                } else {
                    showMessage("Please select an account type.");
                }
            } catch (Exception ex) {
                showMessage("Error creating account. Check input.");
            }
        });

        changeAIRButton.addActionListener(e -> {
            try {
                double newAIR = Double.parseDouble(JOptionPane.showInputDialog("Enter new AIR (e.g. 0.02):"));
                if (depositAccountRadioButton.isSelected()) {
                    DepositAccount.setAIR(newAIR);
                    showMessage("Deposit Account AIR updated.");
                } else if (currentAccountRadioButton.isSelected()) {
                    CurrentAccount.setAIR(newAIR);
                    showMessage("Current Account AIR updated.");
                } else {
                    showMessage("Select account type.");
                }
            } catch (Exception ex) {
                showMessage("Invalid AIR value.");
            }
        });

        changeOverdraftLimitButton.addActionListener(e -> {
            try {
                int id = Integer.parseInt(JOptionPane.showInputDialog("Enter Current Account ID:"));
                Account acc = findAccount(id);
                if (acc instanceof CurrentAccount) {
                    double limit = Double.parseDouble(JOptionPane.showInputDialog("Enter new overdraft limit:"));
                    ((CurrentAccount) acc).setOverdraft(limit);
                    showMessage("Overdraft limit updated.");
                } else {
                    showMessage("Current Account not found.");
                }
            } catch (Exception ex) {
                showMessage("Invalid input.");
            }
        });
    }

    /*private void switchPanel(JPanel panel) {
        rootPanel.removeAll();
        rootPanel.add(panel);
        rootPanel.revalidate();
        rootPanel.repaint();
    }*/

    private Account findAccount(int id) {
        for (Account acc : thomondAccounts) {
            if (acc.getId() == id) return acc;
        }
        return null;
    }

    private void showMessage(String msg) {
        JOptionPane.showMessageDialog(null, msg);
    }

    private void testAccounts() {
        DepositAccount d1 = new DepositAccount(1, 1);
        d1.deposit(500);
        DepositAccount d2 = new DepositAccount(2, 2);
        d2.deposit(1000);
        CurrentAccount c1 = new CurrentAccount(3, 3, 500);
        c1.deposit(250);
        thomondAccounts.add(d1);
        thomondAccounts.add(d2);
        thomondAccounts.add(c1);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("GUI");
        frame.setContentPane(new GUI().rootPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}