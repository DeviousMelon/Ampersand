import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    private static final ArrayList<Vehicle> fleet = new ArrayList<>();
    private static final ArrayList<Booking> bookings = new ArrayList<>();
    private static final ArrayList<Customer> customers = new ArrayList<>();
    private static final ArrayList<Employee> employees = new ArrayList<>();

    public static void main(String[] args) {
        InputData();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the SmartCar System!");

        while (true) {
            System.out.println("\nMain Menu:");
            System.out.println("1. Customer Menu");
            System.out.println("2. Employee Menu");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    customerMenu(scanner);
                    break;
                case 2:
                    employeeMenu(scanner);
                    break;
                case 3:
                    System.out.println("Exiting the system. Goodbye!");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void InputData() {

        fleet.add(new SmartCity(1, "AB1234", "Nissan", "Micra", LocalDate.of(2021, 6, 15), "Limerick", 1.2, 99));
        fleet.add(new SmartTripper(2, "BC2345", "Skoda", "Scala", LocalDate.of(2022, 3, 10), "Ennis", 1.6, 120));
        fleet.add(new SmartElectric(3, "DE4567", "Kia", "EV6", LocalDate.of(2023, 8, 20), "Shannon", 77.0, 500, 6));
        fleet.add(new SmartVan(4, "FG6789", "Ford", "Transit", LocalDate.of(2020, 11, 5), "Nenagh", 2.2, 150));


        customers.add(new Customer(1, "John", "Doe", "john.doe@example.com", "123 Main St, Limerick"));
        customers.add(new Customer(2, "Jane", "Smith", "jane.smith@example.com", "456 Oak Rd, Ennis"));


        employees.add(new Employee(1, "Alice", "Johnson", "alice.j@example.com", "789 Pine Ln, Shannon"));
        employees.add(new Employee(2, "Bob", "Brown", "bob.b@example.com", "321 Maple Ave, Nenagh"));

        System.out.println("Data Input Successfully.");
    }

    // Customer Menu
    private static void customerMenu(Scanner scanner) {
        System.out.println("\nCustomer Menu:");
        System.out.println("1. Sign Up");
        System.out.println("2. Book a Car");
        System.out.println("3. Return a Car");
        System.out.println("4. Go Back");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                signUp(scanner);
                break;
            case 2:
                bookCar(scanner);
                break;
            case 3:
                returnCar(scanner);
                break;
            case 4:
                return;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    //Employee Menu
    private static void employeeMenu(Scanner scanner) {
        System.out.println("\nEmployee Menu:");
        System.out.println("1. Add Vehicle");
        System.out.println("2. Modify Rates");
        System.out.println("3. List Bookings");
        System.out.println("4. List Customers");
        System.out.println("5. List Vehicles");
        System.out.println("6. List Employees");
        System.out.println("7. Go Back");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                addVehicle(scanner);
                break;
            case 2:
                modifyRates(scanner);
                break;
            case 3:
                listBookings();
                break;
            case 4:
                listCustomers();
                break;
            case 5:
                listVehicles();
                break;
            case 6:
                listEmployees();
                break;
            case 7:
                return;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private static void signUp(Scanner scanner) {
        try {
            System.out.println("\n--- Customer Sign-Up ---");
            System.out.print("Enter First Name: ");
            String firstName = scanner.next();
            System.out.print("Enter Last Name: ");
            String lastName = scanner.next();
            System.out.print("Enter Email: ");
            String email = scanner.next();
            System.out.print("Enter Address: ");
            scanner.nextLine(); // Consume newline
            String address = scanner.nextLine();

            int newCustNo = customers.size() + 1; // Auto-generate customer number
            Customer newCustomer = new Customer(newCustNo, firstName, lastName, email, address);
            customers.add(newCustomer);

            System.out.println("Customer signed up successfully! Your Customer Number is: " + newCustNo);
        } catch (Exception e) {
            System.out.println("An error occurred during sign-up. Please try again.");
        }
    }

    private static void bookCar(Scanner scanner) {
        try {
            System.out.println("\n--- Book a Car ---");
            System.out.print("Enter Your Customer Number: ");
            int custNo = scanner.nextInt();

//            Customer customer = customers.stream()
//                    .filter(c -> c.getCustNo() == custNo)
//                    .findFirst()
//                    .orElse(null);

            Customer customer = null;
            for(int i = 0 ; i<customers.size(); i++){
                if(customers.get(i).getCustNo() == custNo){
                    customer = customers.get(i);
                }
            }

            if (customer == null) {
                System.out.println("Invalid Customer Number. Please sign up first.");
                return;
            }

            System.out.println("\nAvailable Vehicles:");
            fleet.forEach(vehicle -> System.out.println(vehicle.id + ": " + vehicle.manufacturer + " " + vehicle.model));
            System.out.print("Enter Vehicle ID to Book: ");
            int vehicleId = scanner.nextInt();

            Vehicle vehicle = fleet.stream()
                    .filter(v -> v.id == vehicleId)
                    .findFirst()
                    .orElse(null);

            if (vehicle == null) {
                System.out.println("Invalid Vehicle ID. Please try again.");
                return;
            }

            System.out.print("Enter Pick-Up Date (yyyy-mm-dd): ");
            LocalDate pickUpDate = LocalDate.parse(scanner.next());
            System.out.print("Enter Pick-Up Time (HH:mm): ");
            LocalTime pickUpTime = LocalTime.parse(scanner.next());
            System.out.print("Enter Return Date (yyyy-mm-dd): ");
            LocalDate returnDate = LocalDate.parse(scanner.next());
            System.out.print("Enter Return Time (HH:mm): ");
            LocalTime returnTime = LocalTime.parse(scanner.next());

            if (returnDate.isBefore(pickUpDate) ||
                    (returnDate.equals(pickUpDate) && returnTime.isBefore(pickUpTime))) {
                System.out.println("Return date/time cannot be earlier than pick-up date/time.");
                return;
            }

            System.out.print("Enter Pick-Up Location: ");
            scanner.nextLine(); // Consume newline
            String pickUpLocation = scanner.nextLine();

            int newBookingId = bookings.size() + 1;
            Booking newBooking = new Booking(
                    newBookingId, vehicleId, custNo,
                    pickUpDate, pickUpTime, returnDate, returnTime, pickUpLocation
            );
            bookings.add(newBooking);

            System.out.println("Booking successful! Your Booking ID is: " + newBookingId);
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please try again.");
            scanner.nextLine(); // Clear invalid input
        } catch (DateTimeParseException e) {
            System.out.println("Invalid date or time format. Please use yyyy-mm-dd for dates and HH:mm for times.");
        } catch (Exception e) {
            System.out.println("An unexpected error occurred. Please try again.");
        }
    }

    private static void returnCar(Scanner scanner) {
        try {
            System.out.println("\n--- Return a Car ---");
            System.out.print("Enter Your Booking ID: ");
            int bookingId = scanner.nextInt();

            Booking booking = bookings.stream()
                    .filter(b -> b.bookingId == bookingId)
                    .findFirst()
                    .orElse(null);

            if (booking == null) {
                System.out.println("Invalid Booking ID. Please try again.");
                return;
            }

            Vehicle vehicle = fleet.stream()
                    .filter(v -> v.id == booking.vehicleId)
                    .findFirst()
                    .orElse(null);

            if (vehicle == null) {
                System.out.println("Error: Vehicle not found.");
                return;
            }

            System.out.print("Enter Total Kilometers Driven: ");
            int kmsDriven = scanner.nextInt();

            long hours = java.time.Duration.between(
                    booking.pickUpTime.atDate(booking.pickUpDate),
                    booking.returnTime.atDate(booking.returnDate)
            ).toHours();

            double totalCost = vehicle.calculateCost((int) hours, kmsDriven);
            System.out.printf("Return successful! Total cost: €%.2f%n", totalCost);

            bookings.remove(booking);
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please try again.");
            scanner.nextLine(); // Clear invalid input
        } catch (Exception e) {
            System.out.println("An unexpected error occurred during the return process. Please try again.");
        }
    }

    private static void addVehicle(Scanner scanner) {
        System.out.println("\n--- Add a Vehicle ---");
        System.out.print("Enter Vehicle Type (SmartCity, SmartTripper, SmartElectric, SmartVan): ");
        String type = scanner.next();

        System.out.print("Enter Manufacturer: ");
        String manufacturer = scanner.next();
        System.out.print("Enter Model: ");
        String model = scanner.next();
        System.out.print("Enter Registration Number: ");
        String regNo = scanner.next();
        System.out.print("Enter Registration Date (yyyy-mm-dd): ");
        LocalDate regDate = LocalDate.parse(scanner.next());
        System.out.print("Enter Location: ");
        scanner.nextLine();
        String location = scanner.nextLine();

        int newId = fleet.size() + 1;

        switch (type) {
            case "SmartCity":
                System.out.print("Enter Engine Size: ");
                double engine = scanner.nextDouble();
                System.out.print("Enter CO2 Emissions: ");
                int co2 = scanner.nextInt();
                fleet.add(new SmartCity(newId, regNo, manufacturer, model, regDate, location, engine, co2));
                break;
            case "SmartTripper":
                System.out.print("Enter Engine Size: ");
                engine = scanner.nextDouble();
                System.out.print("Enter CO2 Emissions: ");
                co2 = scanner.nextInt();
                fleet.add(new SmartTripper(newId, regNo, manufacturer, model, regDate, location, engine, co2));
                break;
            case "SmartElectric":
                System.out.print("Enter Battery Size: ");
                double battery = scanner.nextDouble();
                System.out.print("Enter Range (in km): ");
                int range = scanner.nextInt();
                System.out.print("Enter Efficiency (kWh/km): ");
                int efficiency = scanner.nextInt();
                fleet.add(new SmartElectric(newId, regNo, manufacturer, model, regDate, location, battery, range, efficiency));
                break;
            case "SmartVan":
                System.out.print("Enter Engine Size: ");
                engine = scanner.nextDouble();
                System.out.print("Enter CO2 Emissions: ");
                co2 = scanner.nextInt();
                fleet.add(new SmartVan(newId, regNo, manufacturer, model, regDate, location, engine, co2));
                break;
            default:
                System.out.println("Invalid vehicle type.");
                return;
        }

        System.out.println("Vehicle added successfully!");
    }

    private static void modifyRates(Scanner scanner) {
        try {
            System.out.println("\n--- Modify Rates ---");
            System.out.println("Available Vehicle Types: SmartCity, SmartTripper, SmartElectric, SmartVan");
            System.out.print("Enter Vehicle Type to Modify Rates: ");
            String type = scanner.next();

            System.out.print("Enter New Hourly Rate: ");
            double newHourlyRate = scanner.nextDouble();
            System.out.print("Enter New Daily Rate: ");
            double newDailyRate = scanner.nextDouble();

            switch (type) {
                case "SmartCity":
                    SmartCity.HOURLY_RATE = newHourlyRate;
                    SmartCity.DAILY_RATE = newDailyRate;
                    break;
                case "SmartTripper":
                    SmartTripper.HOURLY_RATE = newHourlyRate;
                    SmartTripper.DAILY_RATE = newDailyRate;
                    break;
                case "SmartElectric":
                    SmartElectric.HOURLY_RATE = newHourlyRate;
                    SmartElectric.DAILY_RATE = newDailyRate;
                    break;
                case "SmartVan":
                    SmartVan.HOURLY_RATE = newHourlyRate;
                    SmartVan.DAILY_RATE = newDailyRate;
                    break;
                default:
                    System.out.println("Invalid vehicle type.");
                    return;
            }

            System.out.printf("Rates for %s updated successfully!%n", type);
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter valid rates.");
            scanner.nextLine(); // Clear invalid input
        } catch (Exception e) {
            System.out.println("An error occurred while updating rates. Please try again.");
        }
    }


    private static void listBookings() {
        System.out.println("\n--- List of Bookings ---");

        if (bookings.isEmpty()) {
            System.out.println("No bookings found.");
            return;
        }

        bookings.forEach(booking -> System.out.printf(
                "Booking ID: %d | Vehicle ID: %d | Customer ID: %d | Pick-Up: %s %s | Return: %s %s | Location: %s%n",
                booking.bookingId, booking.vehicleId, booking.custNo,
                booking.pickUpDate, booking.pickUpTime,
                booking.returnDate, booking.returnTime,
                booking.pickUpLocation
        ));
    }

    private static void listCustomers() {
        System.out.println("\n--- List of Customers ---");

        if (customers.isEmpty()) {
            System.out.println("No customers found.");
            return;
        }

        customers.forEach(customer -> System.out.printf(
                "Customer ID: %d | Name: %s %s | Email: %s | Address: %s%n",
                customer.getCustNo(), customer.firstName, customer.lastName,
                customer.email, customer.address
        ));
    }

    private static void listVehicles() {
        System.out.println("\n--- List of Vehicles ---");

        if (fleet.isEmpty()) {
            System.out.println("No vehicles found.");
            return;
        }

        fleet.forEach(vehicle -> System.out.printf(
                "Vehicle ID: %d | Type: %s | Manufacturer: %s | Model: %s | Reg No: %s | Reg Date: %s | Location: %s%n",
                vehicle.id,
                vehicle.getClass().getSimpleName(),
                vehicle.manufacturer,
                vehicle.model,
                vehicle.regNo,
                vehicle.regDate,
                vehicle.location
        ));
    }

    private static void listEmployees() {
        System.out.println("\n--- List of Employees ---");

        if (employees.isEmpty()) {
            System.out.println("No employees found.");
            return;
        }

        employees.forEach(employee -> System.out.printf(
                "Employee ID: %d | Name: %s %s | Email: %s | Address: %s%n",
                employee.getEmpNo(), employee.firstName, employee.lastName,
                employee.email, employee.address
        ));
    }

}