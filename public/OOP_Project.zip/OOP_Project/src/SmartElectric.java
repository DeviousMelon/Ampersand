import java.time.LocalDate;

// SmartElectric Subclass
public class SmartElectric extends Vehicle {
    public static double HOURLY_RATE = 14.0;
    public static double DAILY_RATE = 70.0;
    private final double battery;
    private final int range;
    private final int efficiency;

    public SmartElectric(int id, String regNo, String manufacturer, String model, LocalDate regDate, String location, double battery, int range, int efficiency) {
        super(id, regNo, manufacturer, model, regDate, location);
        this.battery = battery;
        this.range = range;
        this.efficiency = efficiency;
    }

    @Override
    public double calculateCost(int hours, int kms) {
        return (hours <= 24 ? HOURLY_RATE * hours : DAILY_RATE);
    }
}
