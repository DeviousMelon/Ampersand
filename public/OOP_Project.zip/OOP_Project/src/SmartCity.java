import java.time.LocalDate;

public class SmartCity extends Petrol {
    public static double HOURLY_RATE = 11.0;
    public static double DAILY_RATE = 55.0;

    public SmartCity(int id, String regNo, String manufacturer, String model, LocalDate regDate, String location, double engine, int co2) {
        super(id, regNo, manufacturer, model, regDate, location, engine, co2);
    }

    @Override
    public double calculateCost(int hours, int kms) {
        double cost = (hours <= 24 ? HOURLY_RATE * hours : DAILY_RATE);
        if (kms > 50) cost += (kms - 50) * 0.25;
        return cost;
    }
}