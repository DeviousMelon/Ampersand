import java.time.LocalDate;
import java.time.LocalTime;

public class Booking {
    public int bookingId;
    public int vehicleId;
    public int custNo;
    public LocalDate pickUpDate;
    public LocalTime pickUpTime;
    public LocalDate returnDate;
    public LocalTime returnTime;
    public String pickUpLocation;

    public Booking(int bookingId, int vehicleId, int custNo, LocalDate pickUpDate, LocalTime pickUpTime,
                   LocalDate returnDate, LocalTime returnTime, String pickUpLocation) {
        this.bookingId = bookingId;
        this.vehicleId = vehicleId;
        this.custNo = custNo;
        this.pickUpDate = pickUpDate;
        this.pickUpTime = pickUpTime;
        this.returnDate = returnDate;
        this.returnTime = returnTime;
        this.pickUpLocation = pickUpLocation;
    }

    public String getPickUpLocation() {
        return pickUpLocation;
    }
    public void setPickUpLocation(String pickUpLocation) {
        this.pickUpLocation = pickUpLocation;
    }
    public LocalTime getReturnTime() {
        return returnTime;
    }
    public void setReturnTime(LocalTime returnTime) {
        this.returnTime = returnTime;
    }
    public LocalDate getReturnDate() {
        return returnDate;
    }
    public void setReturnDate(LocalDate returnDate) {
        this.returnDate = returnDate;
    }
    public LocalTime getPickUpTime() {
        return pickUpTime;
    }
    public void setPickUpTime(LocalTime pickUpTime) {
        this.pickUpTime = pickUpTime;
    }
    public LocalDate getPickUpDate() {
        return pickUpDate;
    }
    public void setPickUpDate(LocalDate pickUpDate) {
        this.pickUpDate = pickUpDate;
    }
    public int getCustNo() {
        return custNo;
    }
    public void setCustNo(int custNo) {
        this.custNo = custNo;
    }
    public int getVehicleId() {
        return vehicleId;
    }
    public void setVehicleId(int vehicleId) {
        this.vehicleId = vehicleId;
    }
    public int getBookingId() {
        return bookingId;
    }
    public void setBookingId(int bookingId) {
        this.bookingId = bookingId;
    }
}